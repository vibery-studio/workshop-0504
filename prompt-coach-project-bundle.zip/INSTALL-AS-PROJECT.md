# Install Prompt Coach as a Claude Project (3 minutes)

**Use this if:** you don't have Claude Pro/Max/Team (skill upload requires Pro+) but you DO have a Claude account (Free works — gives you 5 projects).

## Steps

1. Go to https://claude.ai
2. Click **Projects** in the left sidebar → **+ New project**
3. Name it: `Prompt Coach`
4. Description: `Workshop assistant — audits prompts using the 5-test rubric`
5. Click **Create project**
6. In the project, find **Set custom instructions** (or "Edit project instructions")
7. Open `system-prompt.txt` from this folder. Copy ALL of it. Paste into the custom instructions field. **Save.**
8. In the project, find the **Knowledge** section
9. Upload all 5 files from the `knowledge/` folder:
   - `01-five-tests.md`
   - `02-rctco-patterns.md`
   - `03-webmd-domain-glossary.md`
   - `04-templates-by-role.md`
   - `05-context-card-template.md`

## Use it

Open a NEW chat **inside the Project**. Paste your task, prompt, or AI output. Coach activates automatically.

- **Bare task** → Coach asks 5 RCTCO questions
- **Drafted prompt** → Coach scores it 1-5 on the 5 tests, gives 2 fixes
- **Bad AI output** → Coach traces what your prompt missed
- **Team context card** → Coach loads your team's vocab + standards

## Smoke test (60 sec)

Paste this into a chat to verify install:

```
You are a senior PM. Write user stories for our member consent feature in WebMD ONE. Output as a markdown table.
```

You should see Coach respond with `AUDIT —` header, a 5-test scorecard with bars, total score out of 25, and exactly 2 fixes ranked by impact, ending with NEXT MOVE.

If you see a generic helpful response instead → custom instructions didn't save. Re-paste, save again.

