# Install Prompt Coach as a Claude Skill (60 seconds)

**You need:** Claude Pro, Max, Team, or Enterprise plan. (Free plan does not support custom skills.)

## Steps

1. Download `prompt-coach-skill.zip` (the parent zip of this folder)
2. Open https://claude.ai
3. Click your name (bottom left) → **Customize**
4. Click **Skills** in the left sidebar
5. Click **+** (top right) → **+ Create skill**
6. Upload `prompt-coach-skill.zip`
7. Toggle the skill ON
8. Make sure **"Code execution and file creation"** is also toggled ON (skills require it)

## Use it

Open any new Claude chat. Paste your task, prompt, or AI output. Coach activates automatically.

- **Bare task** ("I want to summarize interviews") → Coach asks 5 RCTCO questions
- **Drafted prompt** → Coach scores it 1-5 on the 5 tests, gives 2 fixes
- **Bad AI output** → Coach traces what your prompt missed
- **Team context card** → Coach loads your team's vocab + standards

## Don't have Pro?

See the alternative install methods at [Tony's coach install page] (Tony will share URL Sunday evening).

