# The 5 tests every prompt must pass

A team-asset prompt scores **≥ 18 / 25**.

This file contains:
1. **Per-test anchored rubrics** — the only place where actual scoring happens
2. **Floor rules** — hard caps that override score inflation
3. **Calibration set** — 3 worked examples that anchor your scoring
4. **Mapping to RCTCO** — which slot defends which test

---

## Why anchored rubrics, not generic 1–5

A generic ladder ("5 = explicit, 1 = absent") collapses to vibes. Two evaluators reading the same prompt will diverge by 4–6 points across the scorecard. That's the difference between "ship to your team" and "rewrite from scratch."

The per-test tables below give each score an **observable criterion** specific to that test. A 4 on Reproducibility looks nothing like a 4 on Boundedness — they're different shapes of evidence. Score each test against ITS table, not against a shared mental ladder.

---

## Test 1 — Reproducibility (R + C slots)

**Question:** Can my teammate run this prompt cold and get the same shape of output, without messaging me?

| Score | What the prompt has | Example phrasing |
|---|---|---|
| **5** | Role names a specific persona AND Context names exact product surface AND exact regulation/scope. Zero implicit assumptions. | "You are a senior BA on WebMD ONE. Member consent capture flow. HIPAA + VN PDPL scope. Spec attached." |
| **4** | Role specific, Context names product surface but generic on user role OR regulation. | "You are a senior BA on WebMD ONE. For our consent feature, US users." |
| **3** | Role specific, Context generic ("for our app", "our users"). OR Role generic, Context specific. | "You are a BA. WebMD ONE consent feature, HIPAA scope." |
| **2** | One of R/C present, the other implied or missing. | "Write user stories for our consent feature." (Role missing) |
| **1** | Neither slot fillable from the prompt. | "Help me with stories." |

**Floor rule:** If Role is missing OR generic ("you are an AI", "you are an expert", "you are helpful") → **cannot exceed 2** regardless of Context strength.

**Common failure:** "Write user stories for our consent feature." → whose consent? Member–employer? Member–coach? GDPR? HIPAA? VN PDPL? Score: 1.

---

## Test 2 — Boundedness (Constraints slot)

**Question:** Did the prompt tell AI what NOT to invent?

| Score | What the prompt has | Example phrasing |
|---|---|---|
| **5** | 4+ explicit "don't" rules covering: invention, source citation, missing facts, scope. | "Don't invent quotes — verbatim only. Don't add regulations not in context. Mark unknowns [TBC]. Don't paraphrase AC." |
| **4** | 2–3 explicit "don't" rules. Covers main hallucination risks. | "Don't invent priorities. Don't paraphrase AC. Mark unknowns [TBC]." |
| **3** | 1 explicit "don't" rule, OR several positive constraints that imply boundedness ("only use", "stick to"). | "Only cite sections from the attached spec." |
| **2** | One weak signal — vague "be careful" / "be accurate" / no real constraint. | "Be accurate and don't make stuff up." |
| **1** | No constraints. AI free to fabricate. | "Synthesize this research." |

**Floor rule:** Zero explicit "don't" / "do not" / "never" / "avoid" / negative constraint → **cannot exceed 2**, regardless of how thoughtful the rest reads.

**Common failure:** Synthesizer prompts on user research without "verbatim quotes only" → AI fabricates plausible-sounding quotes. Score: 1.

---

## Test 3 — Testability (Output slot, with Task)

**Question:** Can the output be checked, not just felt?

| Score | What the prompt has | Example phrasing |
|---|---|---|
| **5** | Forced output structure with named columns/keys/tags AND each row/item independently evaluable. | "Markdown table. Columns: Story \| AC (G/W/T) \| Spec ref \| Severity \| Flags. One row per story." |
| **4** | Forced structure but loose on cell-level checkability. | "Markdown table with columns for story, AC, and notes." |
| **3** | Format named but no structure ("bullet list", "numbered list", "JSON"). Reader must interpret per item. | "Give me a JSON list of findings." |
| **2** | Vague format hint, no structure. | "Format it nicely." |
| **1** | "Write a paragraph" / "give me thoughts" / "explain X" — no structure. Reviewer can't say "row 3 is wrong." | "Write a summary about consent." |

**Floor rule:** Output instruction is a vague verb only ("write", "give me", "explain", "draft", "describe") with no shape, format, or structural constraint → **cannot exceed 2**.

**Common failure:** Reviewer prompts that ask for "feedback" instead of a severity-tagged list of findings. Score: 1.

---

## Test 4 — Reusability (all 5 stable, Context placeholders)

**Question:** Can I run this same prompt next sprint by changing only 2–3 inputs?

| Score | What the prompt has | Example phrasing |
|---|---|---|
| **5** | Role + Task + Constraints + Output are stable. Context has clearly bracketed placeholders the next user fills (`[FEATURE]`, `[SPRINT]`, `[SPEC URL]`). | "Context: [FEATURE NAME] · [USER TYPE] · [SPEC LINK]. Sprint [N]." |
| **4** | Reusable in spirit, but 1–2 product/feature names hardcoded inline. | "WebMD ONE consent feature. Spec at [LINK]. Sprint [N]." |
| **3** | Mixed — RCTCO frame is reusable but multiple specifics hardcoded into Context with no clear placeholder pattern. | "WebMD ONE consent. PRD section 3.2. Sprint 14." |
| **2** | Hardcoded to one feature, one sprint, one teammate. Reuse = rewrite. | "Help me write tickets for the consent feature I'm working on this sprint." |
| **1** | Tied to a single moment / single artifact / personal context. | "Take what we discussed in Slack and turn it into stories." |

**Floor rule:** Context contains literal feature/product/customer names hardcoded with NO `[BRACKETS]` or placeholders → **cannot exceed 3**, even if everything else is excellent.

**Common failure:** Best prompt sits in a Slack thread. Next sprint, same task = new prompt from memory. Score: 2.

---

## Test 5 — Auditability (Constraints + Output)

**Question:** If a regulator asks "where did this requirement come from" — can you show the trail in 60 seconds?

| Score | What the prompt has | Example phrasing |
|---|---|---|
| **5** | All 4 audit-trail patterns: source IDs, `[ASSUMPTION]`, `[COMPLIANCE — HIPAA/PDPL]`, `[TBC]`. Required in output structure. | "Each row cites Spec §X.Y. Flag PHI lines [COMPLIANCE — HIPAA]. Mark guesses [ASSUMPTION]. Mark unknowns [TBC]." |
| **4** | 3 of the 4 patterns present. | "Cite spec section. Mark unknowns [TBC]. Flag PHI [COMPLIANCE — HIPAA]." |
| **3** | 2 of the 4 patterns present. | "Cite spec section. Mark unknowns." |
| **2** | 1 audit pattern present, OR audit asked but not enforced in output structure. | "Be careful with compliance." |
| **1** | No source-citation, no assumption tags, no compliance flags, no TBC pattern anywhere. | "Write user stories." |

**Floor rule:** No `[ASSUMPTION]` / `[COMPLIANCE]` / source-citation / `[TBC]` pattern anywhere in the prompt → **cannot exceed 3**, even if Constraints + Output are otherwise strong.

**Common failure:** Auditability is the test that breaks AI use in regulated work. Most teams skip it and find out the hard way. Score: 1.

---

## Hard floor rules (consolidated)

Apply BEFORE scoring. If triggered, the test is capped regardless of other signals. Tell the user *which* floor triggered and *what phrase* to add.

| Floor rule | Cap |
|---|---|
| Role missing OR generic ("you are an AI/expert/helpful") | Reproducibility ≤ 2 |
| Zero explicit "don't" / "never" / "avoid" / negative constraint | Boundedness ≤ 2 |
| Output is a vague verb only with no shape/format/structure | Testability ≤ 2 |
| Context hardcoded with no `[BRACKETS]`/placeholders | Reusability ≤ 3 |
| No `[ASSUMPTION]` / `[COMPLIANCE]` / source-citation / `[TBC]` patterns | Auditability ≤ 3 |

---

## Calibration set — 3 worked examples

Anchor every score against these three. The user's prompt sits somewhere on this gradient — interpolate.

### Example A — "Lucky 1-liner" → 6 / 25

```
Turn this PRD into YouTrack tickets.

[paste PRD section here]
```

| Test | Score | Reason (with evidence) |
|---|---|---|
| Reproducibility | 1 | Role absent. Context = "this PRD" — undefined product, undefined regulation. |
| Boundedness | 1 | Zero "don't" rules. AI free to invent priorities, story points, paraphrase AC. |
| Testability | 1 | "Turn into tickets" — no format, no columns, no shape. Reviewer can't check cell-by-cell. |
| Reusability | 2 | Generic enough to reuse, but no `[BRACKETS]` and no Context structure. |
| Auditability | 1 | Zero `[ASSUMPTION]` / `[COMPLIANCE]` / source-citation pattern. |
| **Total** | **6/25** | **Personal trick. Starting point — identify the missing slots first.** |

### Example B — "RCTCO team-asset baseline" → 18 / 25

```
Role: senior PO on a wellness platform that ships to YouTrack.
Context: WebMD ONE · member consent · HIPAA · 2-week sprints. Spec attached.
Task: convert each user story below into one YouTrack ticket.
Constraints:
  - preserve every AC verbatim — do not paraphrase
  - mark unknowns [TBC: confirm with PM]
  - flag PHI lines [COMPLIANCE — HIPAA]
Output: markdown table —
  | # | Title | Description | AC (G/W/T) | Priority | Labels | Flags |

[paste PRD section here]
```

| Test | Score | Reason (with evidence) |
|---|---|---|
| Reproducibility | 4 | Role specific ("senior PO"), Context names product (WebMD ONE) + user (member) + regulation (HIPAA). Spec attached. Slightly generic on user persona scope. |
| Boundedness | 4 | Three "don't"-style rules: "do not paraphrase", "[TBC] if unknown", "[COMPLIANCE — HIPAA] for PHI". Solid coverage. |
| Testability | 5 | Forced markdown table with 7 named columns. Each row independently checkable. |
| Reusability | 3 | RCTCO frame reusable, but "WebMD ONE", "member consent", "HIPAA" hardcoded with no `[BRACKETS]`. Floor rule applies → cap at 3. |
| Auditability | 2 | Two of four patterns present ([TBC] + [COMPLIANCE]). Missing: source-IDs per claim, [ASSUMPTION] tag. |
| **Total** | **18/25** | **Team asset — light polish. Ship to one teammate, get feedback.** |

### Example C — "RCTCO + injected team context card" → 22 / 25

```
[Team Context Card prepended:]
Vocab: "member" not "user". "engagement score" not "DAU". "claim handoff" not "API call".
DoD: AC in Given/When/Then. [COMPLIANCE — HIPAA] flag if PHI touched. Story points TBC if unknown. Reviewed by 2 leads.
Past example: [paste of last sprint's PRD-to-ticket output, verbatim].

Role: senior PO on [PRODUCT].
Context: [FEATURE NAME] · [USER TYPE: member / coach / HR program manager] · [REGULATION SCOPE]. Spec at [SPEC URL].
Task: convert each user story in the spec into one YouTrack ticket.
Constraints:
  - preserve every AC verbatim — do not paraphrase
  - cite spec section per story (e.g., §3.2)
  - mark every assumption [ASSUMPTION: ...]
  - mark unknowns [TBC: question for PM]
  - flag PHI lines [COMPLIANCE — HIPAA]
  - mirror the past example's format exactly
Output: markdown table —
  | # | Title | Description | AC (G/W/T) | Spec § | Priority | Labels | Flags |
```

| Test | Score | Reason (with evidence) |
|---|---|---|
| Reproducibility | 5 | Role specific. Context fully bracketed but team vocab + past example lock the persona. Anyone on team runs same shape. |
| Boundedness | 5 | Five explicit "don't"-style rules + format-mirror rule. Comprehensive. |
| Testability | 5 | Forced 8-column table. Past example sets the precedent for what each cell looks like. |
| Reusability | 5 | All 5 RCTCO slots stable. Context fully bracketed: `[PRODUCT]`, `[FEATURE NAME]`, `[USER TYPE]`, `[REGULATION SCOPE]`, `[SPEC URL]`. |
| Auditability | 2 | Three of four patterns ([ASSUMPTION], [COMPLIANCE], [TBC] + spec citation). **Missing: explicit source-ID format per claim row.** That's why we cap at 22, not 25 — Auditability is the hardest test. |
| **Total** | **22/25** | **Team asset, audit-ready. Fork into Project, share with team.** |

**The lesson from Example C:** even an excellent prompt rarely hits 25/25 because Auditability has 4 distinct patterns and most production prompts cover 3. A 22 with strong Reproducibility, Boundedness, Testability, Reusability is the realistic ceiling for senior teams. 25/25 is regulatory-grade.

---

## Score interpretation

| Total | Meaning | Action |
|-------|---------|--------|
| 22–25 | Team asset, audit-ready | Fork into Claude Project, share with team |
| 18–21 | Team asset, light polish | Ship to one teammate, get feedback |
| 14–17 | Personal trick | Fix the lowest-scoring 2 tests, re-score |
| Below 14 | Starting point | Identify the missing RCTCO slot first |

---

## Mapping tests to RCTCO

| Test | Primary slot | Secondary |
|------|--------------|-----------|
| Reproducibility | Role | Context |
| Boundedness | Constraints | Context |
| Testability | Output | Task |
| Reusability | All 5 stable | Context placeholders |
| Auditability | Constraints | Output |

---

## How to use this file (for the Coach instance reading it)

1. **Detect mode** — is the user pasting a bare task (BUILD), a draft prompt (AUDIT), an output (DIAGNOSE), or a context card (PERSONALIZE)?
2. **For AUDIT** — for each test:
   - Apply floor rules first. If a floor triggers, cap immediately and note the trigger phrase.
   - Otherwise, find the row in the test's anchored table whose criterion matches what the prompt actually has.
   - Mentally place the prompt against the 3 calibration examples to sanity-check the score.
   - Write the reason line citing the exact phrase (or its absence) — never use vague language like "weak", "could be better", "needs work".
3. **Pick the 2 highest-impact fixes** — usually the two lowest scores, or the two with the steepest fix-to-score gain. Show the exact phrase to add.

This is what separates a real evaluator from a vibes-scorer.
