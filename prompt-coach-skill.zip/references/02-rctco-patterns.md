# RCTCO + the 5 patterns

## RCTCO — the 5 slots every prompt needs

| Slot | What it is | Failure if missing |
|------|------------|---------------------|
| **R**ole | Who the AI is right now ("senior BA on WebMD ONE") | Generic helper output |
| **C**ontext | Product, users, constraints, regulations the AI cannot guess | AI fills blanks creatively (hallucinates) |
| **T**ask | One verb, one outcome ("draft 5 user stories") | AI does something adjacent |
| **C**onstraints | What to avoid, banned content, length, must-include, [ASSUMPTION] tags | Invented quotes, fake regulations |
| **O**utput format | Table? G/W/T? JSON? Severity tags? | Output is prose-soup, can't be checked |

Skip a slot → fail one of the 5 tests.

## The 5 patterns (every product task is one of these)

### 1. Reviewer — score against criteria
- **What it does:** Score an EXISTING artifact against your rubric/DoD; row-by-row severity-tagged findings ("does this meet the bar?")
- **Output shape:** Severity-tagged list (Blocker / Needs attention / Suggestion) with quoted source phrases + proposed rewrites
- **Tests stressed:** Testability (severity tags), Auditability (cite line numbers)
- **Example:** Sharpen a half-baked PRD section before dev handoff

### 2. Synthesizer — find the themes
- **What it does:** Cluster many inputs into themes, no nuance lost
- **Output shape:** Theme table with frequency, source IDs, verbatim quotes; tensions section; weak signals section
- **Tests stressed:** Boundedness (no fake quotes), Auditability (cite source IDs P1, P2…)
- **Example:** 30 user interview snippets → 5 themes + tensions

### 3. Drafter — turn structure into words
- **What it does:** Generate first-pass content from a brief
- **Output shape:** Markdown sections with H2 headers, [ASSUMPTION] tags on unknowns, [TBC] for open questions
- **Tests stressed:** Reproducibility, Reusability (template scales)
- **Example:** PRD section, user stories, UX microcopy

### 4. Critic — find what could go wrong
- **What it does:** Adversarially stress-test a PLAN with no rubric — surface edge cases, failure modes, missing scenarios ("what could break?")
- **Output shape:** Sortable list of concerns by severity + likelihood, each with one mitigation
- **Tests stressed:** Boundedness (no invented objections), Testability (sortable)
- **Example:** Pre-launch review of a feature spec

### 5. Translator — move format or audience
- **What it does:** Same meaning, different shape (PRD → ticket; tech → patient-facing)
- **Output shape:** Side-by-side or row-mapped output, source preserved
- **Tests stressed:** Boundedness (don't change meaning), Auditability (preserve source refs)
- **Example:** Linh's PRD → YouTrack tickets

## Pattern matching cheat

When an attendee describes their task, match to pattern by the verb:

| They say | Pattern |
|----------|---------|
| "review", "check", "score", "find issues in [existing thing]" | **Reviewer** |
| "summarize", "themes", "synthesize", "what do users say" | **Synthesizer** |
| "draft", "write", "generate", "create from scratch" | **Drafter** |
| "critique [a plan]", "what could go wrong", "stress test", "edge cases", "find failure modes" | **Critic** |
| "convert", "translate", "rewrite for X audience", "turn X into Y" | **Translator** |

**Ambiguous "critique" rule:** if the user says "critique X" without signaling whether X is already-drafted work or a proposed plan, ask ONE clarifier before routing: *"Is X already drafted (Reviewer — score against your rubric) or a plan you're proposing (Critic — stress-test for failure modes)?"*

Chains are common: "Drafter → Reviewer" (write a PRD, then score it against your DoD rubric). "Synthesizer → Drafter" (cluster research, then draft a problem statement).
