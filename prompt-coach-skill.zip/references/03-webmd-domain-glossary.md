# WebMD Health Services — domain glossary

The Coach uses this vocabulary by default when building examples or constraints.

## Company

WebMD Health Services (HQ Portland, OR; VN office HCM City, Phú Nhuận). Corporate well-being / employee engagement arm of WebMD. B2B — sells subscription wellness programs to employers, health plans, public sector. NOT the consumer health portal (webmd.com).

## Products

- **WebMD ONE** — flagship corporate wellness platform. Health coaching, biometric tracking, incentive programs, manager dashboards.
- **TINYpulse** — employee engagement / pulse survey product (acquired). Manager loops, sentiment, action items.
- **embody** — community health habits platform.

## User roles (use these names — not "user" or "patient")

| Role | Who they are | Common workflows |
|------|--------------|------------------|
| **Member** | Employee of an enterprise customer using the wellness product | Wellness tracking, biometric capture, content feeds, surveys, coaching sessions |
| **Health coach** | In-house or contracted clinical coach | Coaching session notes, escalation flows, member growth plans |
| **Wellness ambassador** | Customer-side employee championing the program | Engagement comms, peer activation |
| **HR program manager** | Customer-side admin running the program | Engagement reports, incentive config, dashboards |
| **Account manager** | WebMD HS-side relationship owner | Renewals, success metrics, escalations |

## Compliance scope (the real one for this room)

Default to these unless attendee says otherwise:

- **HIPAA (US)** — applies to coaching session content, biometrics, claims data. Business Associate Agreements with employer-customers.
- **VN PDPL (effective 2026)** — applies to data handled by the VN office (engineering/product work).
- **GDPR** — applies if any EU members are in scope.
- **SOC 2** — common enterprise customer ask, applies to platform-wide controls.

When prompting for a feature spec, default constraints should include:
- `[COMPLIANCE — HIPAA]` for any PHI / coaching / biometric touch
- `[COMPLIANCE — PDPL]` for any data flowing through VN-built systems
- `[ASSUMPTION: ...]` for any compliance scope the attendee didn't name

## Common product surfaces (5 surfaces, all attendees fit one)

1. **Member experience** — employee-facing app/web, wellness tracking, content feeds, surveys
2. **Coaching** — coach-side tools, session notes, member dialogues, escalation
3. **HR admin** — program manager dashboards, engagement reports, incentive setup
4. **Engagement / pulse** — TINYpulse-style surveys, sentiment analysis, manager action loops
5. **Platform / shared** — auth, integrations, claims handoffs, compliance, audit trails

When an attendee names their surface, use that surface's vocabulary.

## Tech stack hints (from survey)

- **YouTrack** (JetBrains) — issue tracking. Linh's PRDs flow into YouTrack tickets. Probably also IntelliJ/JetBrains tooling on engineering side.
- **Confluence-alt:** likely YouTrack Knowledge Base (not Confluence/Notion).
- Attendees mostly: PO, BA, designer, UX manager. Some engineers may attend unsurveyed.

## Data shapes (for output-format coaching)

| Artifact | Typical fields | Output format hint |
|----------|----------------|---------------------|
| YouTrack ticket | Title, description, AC (G/W/T), priority, labels, story points, assignee | Markdown table with these columns |
| Coaching session note | Member ID (placeholder), date, focus area, observations, next steps, escalations | Structured markdown with H3 sections |
| Engagement report | Time period, segment, KPI, value, trend, commentary | Table per segment, narrative under |
| Pulse survey theme | Theme name, frequency, source-IDs, verbatim quotes (2), tension flag | Synthesizer pattern table |
| PRD section | Problem, goals, non-goals, user stories, AC, edge cases, open Qs | Markdown H2 sections, fixed order |

## Example placeholder values (use these instead of inventing)

- Member: `Member A`, `Member B`, `M-1234` (never real IDs)
- Coach: `Coach 1`, `Coach H` (never real names)
- Employer: `Employer Co`, `Customer X`
- Survey response: `Response P1`, `P2`, `P3`
