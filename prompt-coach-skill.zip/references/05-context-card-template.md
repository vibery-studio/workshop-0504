# Context Card Template — your team's voice for any prompt

> **Two ways to use this template:**
> · **Solo:** copy the structure below, fill the brackets with your team's words.
> · **With Coach:** paste your raw notes (vocab, DoD, example) into Prompt Coach and ask *"format this as a Context Card."* Coach returns clean markdown using this exact shape.

Fill this once. Paste it into any Coach chat (or any Claude chat) BEFORE your prompt. It turns generic prompts into yours.

> **How to use:** Copy this template. Replace every `[BRACKET]` with your team's reality. Save it somewhere you can paste from (Notes app, sticky bookmark, Notion, Confluence). When you start any new prompt, paste this first, then write your task.

---

## ===== COPY FROM HERE =====

**TEAM CONTEXT — read this before responding:**

### Layer 1 — How my team talks
- Product names: `[e.g., WebMD ONE / TINYpulse / embody]`
- We say "**member**" not "user" / "patient"
- We say "**health coach**" not "clinician" / "therapist"
- We say "**HR program manager**" not "HR admin"
- Our ticket system: `[YouTrack / Jira / Linear]`
- Our PRD home: `[Confluence / YouTrack KB / Notion]`
- Internal acronyms: `[list 3-5 your team uses, e.g., "BAA = Business Associate Agreement"]`
- Sprint cadence: `[2-week sprints / weekly / continuous]`
- Banned phrases: `[e.g., never use "Oops!" in member-facing copy; never imply medical advice]`

### Layer 2 — Our quality bar
- **Definition of Done** (paste your team's actual DoD checklist):
  ```
  [- AC in G/W/T format
   - 1 mockup link
   - Compliance flag if PHI/PII touched
   - Edge case list (empty / failure / permission)
   - QA test plan]
  ```
- **AC format we use:** `[Given / When / Then]`
- **PRD section order we follow:** `[Problem → Goals → Non-goals → User stories → AC → Edge cases → Open questions]`
- **Compliance flags we use:** `[COMPLIANCE — HIPAA] / [COMPLIANCE — PDPL] / [COMPLIANCE — SOC2]`
- **Always mark assumptions:** `[ASSUMPTION: ...]`
- **Always mark unknowns:** `[TBC: question for [name/role]]`

### Layer 3 — One example of past good work
*The magic ingredient. Paste ONE real artifact you're proud of — sanitized.*

```
[PASTE one of:
 - 1 past PRD section that shipped clean
 - 1 past YouTrack ticket your dev called "perfect handoff"
 - 1 past research synthesis your PM thanked you for
 - 1 past member-facing copy that passed brand review

Sanitize: replace real member names with [Member A], real customer names with [Employer Co]. Keep the SHAPE intact.]
```

### Constraints (always apply)
- Never invent product names not listed above
- Never invent regulations not in this context
- Mark every assumption with `[ASSUMPTION: ...]`
- Mark every compliance touch with the appropriate flag
- Use my team's vocabulary — never default to generic "user/patient/clinician"
- If I ask for a PRD section, follow our PRD section order exactly
- If I ask for tickets, match the shape of my example

---

## ===== END COPY =====

## How to use it in practice

**With Prompt Coach (workshop tool):**
1. Open Coach
2. Paste this entire context card as your FIRST message
3. Coach responds: *"Context loaded. Ready for your task."*
4. Now write any task — Coach scores it against the 5 tests AND your team standards

**With any Claude chat:**
1. Paste this context card
2. Then paste: "Here is my task: [your prompt]"
3. Claude follows the context

**With Claude Projects:**
1. Save this context card as `team-context.md`
2. Upload it as a Project knowledge file
3. Every chat in that Project uses it automatically — never paste again

## When to update it

Quarterly. Or when:
- Your team adopts a new acronym
- DoD changes
- A new compliance requirement lands
- You ship a new "best example" you'd want AI to mimic

The context card grows with your team. It IS your team's institutional voice — externalized.

## The score jump

Without context card: generic prompt scores ~18/25 on the 5 tests.

With context card: same prompt scores ~22/25 — because Reproducibility (everyone uses same vocab) and Auditability (compliance flags built in) jump automatically.

That is the leverage. **One file. Every prompt. Forever.**
